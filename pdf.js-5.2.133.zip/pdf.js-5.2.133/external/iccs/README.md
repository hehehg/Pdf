## ICC

The file CGATS001Compat-v2-micro.icc used to convert colors from CMYK to RGB comes from:
https://github.com/saucecontrol/Compact-ICC-Profiles

at revision bdd84663061bc4ae95ca70decff54f581e27f702.

## Licensing

[CGATS001Compat-v2-micro.icc](https://github.com/saucecontrol/Compact-ICC-Profiles/blob/master/profiles/CGATS001Compat-v2-micro.icc) is under [CC0-1.0](https://creativecommons.org/publicdomain/zero/1.0/).