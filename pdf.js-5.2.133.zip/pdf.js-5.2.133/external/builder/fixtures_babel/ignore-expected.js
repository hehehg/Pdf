const wasmUrl = new URL(
/*webpackIgnore: true*/
/*@vite-ignore*/
"qwerty.wasm", import.meta.url);
