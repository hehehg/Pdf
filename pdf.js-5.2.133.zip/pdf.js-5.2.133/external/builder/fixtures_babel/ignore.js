const wasmUrl = new URL("qwerty.wasm" , import.meta.url);
